-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 11 Jul 2022 pada 09.48
-- Versi server: 10.4.24-MariaDB
-- Versi PHP: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `laundrycim`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `karyawan`
--

CREATE TABLE `karyawan` (
  `karyawan_id` char(4) NOT NULL,
  `nama_karyawan` varchar(50) NOT NULL,
  `jeniskelamin` varchar(10) NOT NULL,
  `alamat` text NOT NULL,
  `no_hp` varchar(15) NOT NULL,
  `gaji_perbulan` int(11) NOT NULL,
  `tgl_bergabung` date NOT NULL,
  `tgl_berhenti` date NOT NULL,
  `aktif` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `karyawan`
--

INSERT INTO `karyawan` (`karyawan_id`, `nama_karyawan`, `jeniskelamin`, `alamat`, `no_hp`, `gaji_perbulan`, `tgl_bergabung`, `tgl_berhenti`, `aktif`) VALUES
('K000', 'Liam Moore', 'Male', '7869 Ralph Street', '096001588696', 0, '2018-01-01', '0000-00-00', 2),
('K001', 'Cythia Eddyn', 'Female', '2902 Drainer Avenue', '08123456792', 1360, '2019-10-06', '2021-01-25', 0),
('K002', 'Curt Payne', 'Male', '2277 Elsie Drive', '087840927394', 1450, '2019-12-04', '2021-02-22', 0),
('K004', 'Christine Moore', 'Female', '8600 Allace Avenue', '08122334458', 1400, '2020-02-03', '2022-06-22', 0),
('K005', 'Clea Randolph', 'Female', '3914 Dennison Street', '78500014714', 1600, '2021-05-04', '0000-00-00', 1),
('K006', 'Thomas', 'Male', '4572 Emily Drive', '71400000250', 1560, '2021-08-01', '0000-00-00', 1),
('K008', 'alda', 'Female', 'blitar', '089789988888', 500000, '2022-06-16', '2022-06-25', 0),
('K009', 'Ohsan', 'Male', 'Blitar', '08976474747', 1000000, '2022-06-28', '0000-00-00', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `pelanggan`
--

CREATE TABLE `pelanggan` (
  `id` int(11) NOT NULL,
  `pelanggan_id` char(150) NOT NULL,
  `nama_pelanggan` varchar(50) NOT NULL,
  `jeniskelamin` varchar(10) NOT NULL,
  `alamat` text NOT NULL,
  `no_hp` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `pelanggan`
--

INSERT INTO `pelanggan` (`id`, `pelanggan_id`, `nama_pelanggan`, `jeniskelamin`, `alamat`, `no_hp`) VALUES
(1, 'P001', 'Brenda Roach', 'Female', '3641 Frum Street', '081243568387'),
(10, 'P0010', 'Larry Meuller', 'Male', '85 Stom Avenue', '72566600150'),
(2, 'P002', 'Gerald Whisler', 'Male', '1005 Heliport Loop', '08234454345'),
(3, 'P003', 'Johnny Smith', 'Male', '4327 Nuzum Court', '082284003073'),
(4, 'P004', 'Misti R Hurd', 'Female', '398 Central Avenue', '082282553856'),
(5, 'P005', 'Antonio Waree', 'Male', '704 Brown Street', '08236749827'),
(6, 'P006', 'Amber Slank', 'Female', '1518 Wilkinson Court', '085634872555'),
(7, 'P007', 'Joseph Howie', 'Male', '2254 Norma Avenue', '085544338866'),
(8, 'P008', 'James Smith', 'Laki-Laki', '7125 Demo Street', '01478541000'),
(9, 'P009', 'Karen Peige', 'Female', '4552 Poling Farm Road', '74100025690');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pengeluaran`
--

CREATE TABLE `pengeluaran` (
  `pengeluaran_id` varchar(14) NOT NULL,
  `total` int(11) NOT NULL,
  `detail` varchar(100) NOT NULL,
  `tgl_pengeluaran` date NOT NULL,
  `karyawan_id` varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `pengeluaran`
--

INSERT INTO `pengeluaran` (`pengeluaran_id`, `total`, `detail`, `tgl_pengeluaran`, `karyawan_id`) VALUES
('20210130093105', 5503, 'Washers Bought', '2021-01-01', 'K004'),
('20210130104609', 4260, 'Salary Payment January 2021', '2021-01-30', 'K000'),
('20210130110802', 466, 'Electricity Bills', '2021-06-16', 'K004'),
('20210805095557', 3000, 'Employee Salary Payment July 2021', '2021-07-02', 'K000'),
('20210805095931', 3000, 'Employee Salary Payment August 2021', '2021-08-05', 'K000'),
('20220607042036', 4560, 'Employee Salary Payment June 2022', '2022-06-07', 'K000');

-- --------------------------------------------------------

--
-- Struktur dari tabel `transaksi`
--

CREATE TABLE `transaksi` (
  `transaksi_id` varchar(14) NOT NULL,
  `pelanggan_id` char(7) NOT NULL,
  `karyawan_id` char(6) NOT NULL,
  `berat` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `tgl_order` date NOT NULL,
  `tgl_selesai` date DEFAULT NULL,
  `status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `transaksi`
--

INSERT INTO `transaksi` (`transaksi_id`, `pelanggan_id`, `karyawan_id`, `berat`, `total`, `tgl_order`, `tgl_selesai`, `status`) VALUES
('20220621122441', 'P001', 'K006', 2, 100000, '2022-06-21', '2022-06-22', 0),
('20220621122600', 'P001', 'K005', 2, 100000, '2022-06-21', '2022-06-23', 0),
('20220628062542', 'P001', 'K006', 2, 100000, '2022-06-28', '0000-00-00', 1),
('20220628092828', 'P0010', 'K009', 3, 150000, '2022-06-28', '2022-06-29', 0),
('20220628093346', 'P001', 'K005', 4, 200000, '2022-06-28', '2022-06-27', 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `user_id` char(4) NOT NULL,
  `namauser` varchar(30) DEFAULT NULL,
  `username` varchar(20) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `level` char(16) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`user_id`, `namauser`, `username`, `password`, `level`) VALUES
('U001', 'Liam Moore', 'admin', '21232f297a57a5a743894a0e4a801fc3', 'superuser');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `karyawan`
--
ALTER TABLE `karyawan`
  ADD PRIMARY KEY (`karyawan_id`);

--
-- Indeks untuk tabel `pelanggan`
--
ALTER TABLE `pelanggan`
  ADD PRIMARY KEY (`pelanggan_id`),
  ADD UNIQUE KEY `UNIQUE` (`id`);

--
-- Indeks untuk tabel `pengeluaran`
--
ALTER TABLE `pengeluaran`
  ADD PRIMARY KEY (`pengeluaran_id`),
  ADD KEY `karyawan_id` (`karyawan_id`);

--
-- Indeks untuk tabel `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`transaksi_id`),
  ADD KEY `pelanggan_id` (`pelanggan_id`),
  ADD KEY `karyawan_id` (`karyawan_id`);

--
-- Indeks untuk tabel `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `pelanggan`
--
ALTER TABLE `pelanggan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `pengeluaran`
--
ALTER TABLE `pengeluaran`
  ADD CONSTRAINT `pengeluaran_ibfk_1` FOREIGN KEY (`karyawan_id`) REFERENCES `karyawan` (`karyawan_id`);

--
-- Ketidakleluasaan untuk tabel `transaksi`
--
ALTER TABLE `transaksi`
  ADD CONSTRAINT `transaksi_ibfk_1` FOREIGN KEY (`pelanggan_id`) REFERENCES `pelanggan` (`pelanggan_id`),
  ADD CONSTRAINT `transaksi_ibfk_2` FOREIGN KEY (`karyawan_id`) REFERENCES `karyawan` (`karyawan_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
